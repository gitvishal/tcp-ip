#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <pthread.h>

#define MAXIMUM 5
#define BUFFERSIZE 15
#define PORTNUM 8787

void *PerClientThread(void *clients);
void ReportError(char *errorMessage);
int TCPServerSocket(unsigned short port);
int TCPAccept(int serverSocket);
void TCPClient(int clientSocket);
char *RandomString();


struct ThreadClients
	{
		int clientSocket;
	};

int main(int argc,char *argv[])
{
/* variable */
/*create socket*/
/*call bind*/
/*listen*/
/*accept*/
	int serverSocket;
	int clientSocket;
	unsigned short serverPort;
	int option=0;
	serverPort=8787;
	pthread_t threadID;
	struct ThreadClients *threadClients;
	
	
	//option -p for port
	while((option=getopt(argc,argv,"p:"))!=-1)
	{
		if (option=='p')
			serverPort=atoi(optarg);
	}
	printf("serverPort:%d\n",serverPort);
	serverSocket=TCPServerSocket(serverPort);

	while(1)
	{
		clientSocket=TCPAccept(serverSocket);
		if ((threadClients = (struct ThreadClients *) malloc(sizeof(struct ThreadClients)))== NULL)
			ReportError("memory allocation failed");
		threadClients->clientSocket= clientSocket;
		if (pthread_create(&threadID,NULL,PerClientThread,(void *)threadClients)!=0)
		{
			ReportError("thread creation failed");
		}
			
		printf("thread client id %ld\n", (long int) threadID);
	}
		
	return 0;
}

void *PerClientThread(void *clients)
{
	int clientSocket;
	pthread_detach(pthread_self());
	clientSocket=((struct ThreadClients *) clients)->clientSocket;
	free(clients);
	TCPClient(clientSocket);
	return(NULL);
	}

void ReportError(char *errorMessage)
{
	perror(errorMessage);
	exit(1);
}

int TCPServerSocket(unsigned short port)
{
	int serverSocket;
	struct sockaddr_in serverAddress;

	//create socket

	if ((serverSocket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
		ReportError("Failed to create server socket");

	//local address

	memset(&serverAddress,0,sizeof(serverAddress));
	serverAddress.sin_family=AF_INET;
	serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddress.sin_port = htons(port);

	//binding

	if(bind(serverSocket, (struct sockaddr *) &serverAddress,sizeof(serverAddress))<0)
		ReportError("binding failed");

	//listening

	if (listen(serverSocket,MAXIMUM)<0)
		ReportError("listen failed");
	
	return serverSocket;

}

int TCPAccept(int serverSocket)
{
	int clientSocket;
	struct sockaddr_in clientAddress;
	unsigned int AddressLen;
	
	AddressLen=sizeof(clientAddress);//length of client address
	//client connection
	if((clientSocket= accept(serverSocket, (struct sockaddr *) &clientAddress,&AddressLen)) < 0)
		ReportError("accept failed");
	printf("Accepted client:%s\n", inet_ntoa(clientAddress.sin_addr)) ;

	return clientSocket;
}

void TCPClient(int clientSocket)
{
	char receiveMessage[BUFFERSIZE];
	int messageSize;
	int keepTalking=1;

	char *response;
	response=RandomString();


	while(keepTalking>0)
	{
		memset(receiveMessage,'\0',sizeof(receiveMessage));
	
	if((messageSize=recv(clientSocket,receiveMessage,BUFFERSIZE,0))<0)
	{
		printf("receive message failed\n");
		
	}
	else
	{
	perror(receiveMessage);
	if(strcmp(receiveMessage,"GETMESSAGE")==0)
		{
			//strcat(response,"GEZXZXXZZX");
			if (send(clientSocket,response,strlen(response),0) !=(strlen(response)))
				printf("error in sending\n");
			
			keepTalking=messageSize;

		}
	else if(strcmp(receiveMessage,"BYE")==0)
		{
			keepTalking=0;
		}
	else
		{
			
			if (send(clientSocket,"Bad Request",11,0) !=11)
				printf("error in sending \n");
			
			keepTalking=messageSize;
		}

	}	
		
	}
	printf("socket closed\n");
	close(clientSocket);
	
}

char *RandomString()
{
	char *src=malloc(80*sizeof(char));;
	char *dest=malloc(80*sizeof(char));;
	char charset[]="1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
	int length=50;
	size_t index,i=0;
	while((length--) > 0)
	{
		index =rand() %(int)(sizeof(charset)-1);
		src[i++]=charset[index];
	}

	strcpy(dest, "The message is ");

	strcat(dest, src);
	return dest;
	}

