import socket
import sys
import logging
LOG_FILENAME='client.log'
logging.basicConfig(filename=LOG_FILENAME,level=logging.INFO)

if len(sys.argv)!=4:
	print "arguments are out of number"
	sys.exit(1)
else:
	serverIP=sys.argv[1]
	serverPort=int(sys.argv[2])
	numberOfRequest=int(sys.argv[3])
	clientSocket= socket.socket()
	clientSocket.connect((serverIP,serverPort))
	print "connected"
	i=0
	while numberOfRequest>i:
		msg=raw_input("send:");
		clientSocket.send(msg)
		data=clientSocket.recv(100)
		if len(data)==0:
			i=numberOfRequest
		else:
			print 'receive:',data
			logging.info(data)
		i+=1
	clientSocket.close()
	print('program Terminated')
		
	


